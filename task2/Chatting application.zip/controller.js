
console.log("abc");
$("#butt1").click(function()
{
	
	var data=d.collect();
	s.save(data);
	});


function update()
{
	this.gotData=function(sending)
	{
		ui.goGogo(sending);
	}
}
var up=new update();